package co.edu.unbosque.SnakesAndLadders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnakesAndLaddersApplicationTests {

	@Test
	void contextLoads() {
	}

}
